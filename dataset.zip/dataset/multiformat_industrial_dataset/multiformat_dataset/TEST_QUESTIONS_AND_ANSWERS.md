# Multi-Format Test Dataset — Questions & Ground-Truth Answers

15 files, 7 real formats (xlsx, docx, PDF text-native, PDF image-only/scanned, PNG engineering
drawing, .eml email — including one multipart email with a real embedded PDF attachment — and
JSON sensor log). Same underlying P-101 story as before, so answers are internally consistent —
but now your ingestion pipeline has to actually parse each format correctly to find them. A
system that only handles clean PDFs/text will visibly fail several questions below.

---

## A. Format-specific extraction (tests whether ingestion actually works per format)

**Q1 — [Excel] What is the total downtime in hours across all work orders for P-101?**
✅ Answer: 26 hours (6 + 2 + 18 from WO-4501, WO-4515, WO-4521).
Source: `Equipment_and_WorkOrder_Log.xlsx`, "Work Order Log" sheet (or "Summary" sheet, cell B6,
which computes this via `SUMIF` formula).
*Tests whether your ingestion reads .xlsx natively (via openpyxl/pandas) rather than just
treating it as unstructured text — and whether it can use a pre-computed summary sheet.*

**Q2 — [Word/.docx] Per SOP-12, what is the vibration trip threshold, and what document is it aligned with?**
✅ Answer: 7.0 mm/s RMS; aligned with OISD-108 (illustrative) guidelines on rotating equipment
reliability.
Source: `SOP-12_Lubrication_Vibration_Monitoring.docx`.
*Tests .docx parsing — this document has both a formatted table and body text; the answer needs
the table (threshold) plus the closing reference line.*

**Q3 — [Scanned PDF, image-only] What did the scanned inspection form for C-501 record as the linked work order?**
✅ Answer: WO-4550.
Source: `Inspection_Report_C501_SCANNED.pdf`.
*This file has ZERO extractable text layer — verified via `pdftotext`, which returns nothing.
If your system answers this correctly, it's actually running OCR. If it fails or hallucinates,
your OCR step isn't wired into ingestion — this is the single most diagnostic question in the
set.*

**Q4 — [PNG engineering drawing / P&ID] According to the P&ID, what is the flow path of cooling water from the tank to the process area, and what protects HE-601?**
✅ Answer: Flow path: T-301 → V-204 → P-101 → HE-601 → Process Area 1 (with P-102 installed in
parallel as a standby pump). PSV-105 protects HE-601's outlet and relieves to the flare header.
Source: `PID_ProcessArea3_CoolingWater.png` (drawing notes + symbol layout).
*Tests computer vision / diagram parsing specifically. A text-only RAG system cannot answer this
at all since there's no OCR-able running text — it requires either a fine-tuned symbol detector,
or at minimum OCR on the drawing's printed labels and notes combined with spatial reasoning.
This is the hardest, most differentiating question in the whole set — exactly the P&ID
challenge called out in the brief as CV work.*

**Q5 — [JSON sensor log] On what date did P-101's vibration first exceed the SOP-12 trip threshold, and what was the reading?**
✅ Answer: 2025-03-03, at 7.4 mm/s RMS (explicitly annotated in the log as exceeding the 7.0
mm/s trip threshold).
Source: `Sensor_Log_P101_Vibration.json`.
*Tests structured JSON parsing and numeric threshold comparison — note the reading crossed
threshold on 2025-03-03, four days before the WO-4521 trip event on 2025-03-11 — a genuine
early-warning signal your system should be able to surface.*

**Q6 — [Email, .eml] Who requested reordering extra stock of DE Bearing 6309, and why?**
✅ Answer: Procurement (procurement@plant.local), because the second P-101 bearing failure that
year (WO-4521) had reduced stock to 2 units, and they recommended reordering 6 units instead of
the usual 1-for-1 replacement, given the recurring failure pattern.
Source: `Email_Archive_EML/004_bearing_stock_reorder.eml`.

**Q6b — [Email threading] Which two emails form a reply thread, and how would your system know they're connected without re-reading both bodies?**
✅ Answer: `001_P101_vibration_flag.eml` (from N. Deshmukh) and
`002_P101_vibration_reply.eml` (reply from R. Kulkarni). They're connected via the
`In-Reply-To` and `References` headers in email 002, which point to email 001's `Message-ID` —
standard RFC822 threading, not just subject-line matching ("RE: RE: ...").
*Tests whether your ingestion parses email headers structurally (via Python's `email` module or
equivalent) rather than treating .eml files as flat text blobs — a flat-text approach loses the
explicit thread relationship entirely.*

---

## A2. The specific "regulatory submissions scattered in email" problem (directly from the brief)

The brief's problem context specifically names this failure mode: *"regulatory submissions
scattered across email archives."* One email in this dataset is a genuine instance of it —
a real regulatory filing that exists ONLY as an email attachment, never logged in the
structured compliance system.

**Q7 — [Regulatory submission buried in email] Find the Consent to Operate renewal application. What is its acknowledgment number, and what equipment does it cover?**
✅ Answer: Acknowledgment No. ACK-77210-2025 (Application No. PCB-CTO-2025-04471), covering the
Process Area 3 cooling water discharge point — specifically equipment T-301, P-101, P-102, and
HE-601. Current consent expires 2025-12-31; renewal requested for 2026-01-01 to 2027-12-31.
Source: `Email_Archive_EML/006_Regulatory_Submission_ConsentRenewal.eml`, attachment
`Consent_to_Operate_Renewal_Application.pdf` (a genuine PDF attachment inside the .eml — verify
your system actually opens and reads the attachment, not just the email body).
*This tests two things at once: (1) does your ingestion extract attachments from .eml files at
all — many naive email parsers only read the message body and silently skip attachments, and
(2) does the extracted content get linked into your knowledge graph against the same equipment
tags (T-301, P-101, etc.) used everywhere else in the dataset.*

**Q8 — Is this Consent to Operate renewal cross-referenced anywhere in the structured compliance system (e.g. the Compliance Audit Package)?**
✅ Answer: No. It appears nowhere in `Compliance_Audit_Package_ProcessArea3.pdf` or any other
structured record in this dataset — it exists only inside the email attachment. This is a
direct, deliberate illustration of the brief's stated problem: a real regulatory submission
"scattered" in an email archive, invisible to anyone not specifically searching that mailbox.
*This is your best demo question for the Compliance Intelligence agent specifically — a system
that surfaces "this regulatory filing exists but isn't tracked in your compliance system" is
solving the exact fragmentation problem named in the brief's opening paragraph, not just doing
generic document Q&A.*

---

## B. Cross-format multi-hop reasoning (tests your knowledge graph across format boundaries)

**Q7 — Combine the sensor log and the inspection PDF: does the JSON telemetry data corroborate the vibration reading in INSP-2201?**
✅ Answer: Yes — INSP-2201 (PDF) reports 6.8 mm/s RMS on 2025-02-10, and the JSON sensor log
shows exactly 6.8 on the same date, explicitly annotated as "Corresponds to INSP-2201 flagged
reading." The two independently-formatted sources agree.
Sources: `Inspection_Report_INSP-2201.pdf` + `Sensor_Log_P101_Vibration.json`.
*This is a genuine cross-format consistency check — tests whether your graph/retrieval links a
PDF table value to a JSON time-series value for the same entity and date.*

**Q8 — Using the OEM manual and SOP-12, what is the expected bearing life under compliant conditions, and by how much can contaminated water reduce it?**
✅ Answer: Expected bearing life is 18–24 months under compliant lubrication and water-quality
conditions (per OEM manual); contaminated cooling water (particulate above 10 ppm spec, per
SOP-12) can reduce bearing service life by up to 40% (per OEM manual).
Sources: `OEM_Manual_Excerpt_P101_Pump.pdf` (Sections 6.1, 6.2, 6.4) + `SOP-12...docx` (Section
3, water quality spec).
*Tests linking a PDF (OEM manual) to a Word doc (SOP) via the shared concept of water quality
spec — no shared ID field, purely semantic/entity linking.*

**Q9 — What does the Compliance Audit Package say about the deviation between SOP-12's mandated lubrication interval and the actual interval found during INSP-2201, and is that a one-time issue or a process gap?**
✅ Answer: SOP-12 mandates a 60-day interval; INSP-2201 found the actual interval was 95 days,
a 58% deviation. The compliance package states this exceeds OISD-108's 25% deviation-logging
threshold and represents a compliance gap in the deviation-logging *process*, not a one-time
missed lubrication event.
Source: `Compliance_Audit_Package_ProcessArea3.pdf` (references SOP-12, INSP-2201, WO-4521 in
its evidence table).
*Tests whether your system distinguishes "computed from raw data" vs. "explicitly stated
conclusion in a compliance document" — a well-designed system should be able to answer this
either way and ideally note both.*

**Q10 — Trace the full escalation chain for the March 2025 P-101 failure across every document type in this dataset.**
✅ Answer (multi-source chain): JSON sensor log shows vibration climbing from 2.1 → 8.1 mm/s
RMS between 2025-01-15 and 2025-03-11, crossing the SOP-12 trip threshold on 2025-03-03 →
INSP-2201 (PDF) formally flagged the issue on 2025-02-10 at 6.8 mm/s RMS, citing lubrication
overdue by 95 days vs. the 60-day SOP-12 spec (Word doc) → Email thread (deshmukh/kulkarni,
2025-02-11/12) discusses the flagged inspection and notes the repeat pattern vs. WO-4501 →
WO-4521 (Excel) records the resulting bearing failure and repair on 2025-03-11 → INC-1102
(Word doc) formally documents this as the second bearing failure in 9 months with root cause
analysis → Procurement email discusses resulting spare-parts stock impact.
Sources: ALL 6 formats — `Sensor_Log_P101_Vibration.json`, `Inspection_Report_INSP-2201.pdf`,
`SOP-12...docx`, `Email_Archive_EML/001_P101_vibration_flag.eml` +
`002_P101_vibration_reply.eml`, `Equipment_and_WorkOrder_Log.xlsx`,
`Incident_Report_INC-1102.docx`.
*This is the single best "wow" demo question for judges — it proves your system genuinely
unifies heterogeneous formats into one coherent timeline, which is the exact language of the
brief ("unified asset & operations brain"). If your system can answer this well with correct
citations across all 6 sources, that's your strongest live demo moment.*

---

## Scoring Guide

| Question | Format tested | What failing it tells you |
|---|---|---|
| Q1 | Excel (.xlsx) | Not parsing spreadsheets natively |
| Q2 | Word (.docx) | Not parsing tables inside Word docs |
| Q3 | Scanned PDF (image-only) | **OCR not actually wired into ingestion** — check this first |
| Q4 | PNG / P&ID | No CV/diagram-parsing capability — expected to be your weakest area, per earlier build-priority notes |
| Q5 | JSON | Not ingesting structured telemetry / time-series data |
| Q6 / Q6b | .eml email + threading | Not parsing email headers structurally, or missing thread relationships |
| Q7 | .eml attachment extraction | **Silently skipping attachments** — a common naive-parser failure, this attachment is a real PDF |
| Q8 | Cross-format compliance gap detection | Not distinguishing "document exists" from "document is tracked in compliance system" — this is the brief's core fragmentation problem, worth the most points if you nail it |
| Q7–Q10 | Cross-format graph | Retrieval is siloed by format/collection rather than unified — this is the core "knowledge graph" requirement from the brief |

**Recommended test order:** run Q1, Q2, Q6 first (should all pass easily — if any fail, your
basic ingestion has a bug, not a capability gap). Then Q3 and Q5 (format-specific capability
checks). Q4 is expected to be hard — treat it as a stretch goal, not a must-pass, per the
earlier guidance that P&ID computer vision is the most expensive component for the value it
demos. Save Q10 for your live demo — it's the one question that actually proves the "unified
knowledge graph" claim in front of judges.
